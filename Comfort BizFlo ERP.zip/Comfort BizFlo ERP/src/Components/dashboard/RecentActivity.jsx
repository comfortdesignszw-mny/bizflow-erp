import React from "react";
import { Clock, UserCheck, UserX, LogIn, LogOut } from "lucide-react";
import { cn } from "@/lib/utils";

const iconMap = {
  IN: { icon: LogIn, color: "text-emerald-600 bg-emerald-50" },
  OUT: { icon: LogOut, color: "text-rose-600 bg-rose-50" },
};

export default function RecentActivity({ accessLogs }) {
  return (
    <div className="bg-white rounded-2xl border border-slate-200/60 p-5">
      <h3 className="text-sm font-semibold text-slate-900 mb-4">Recent Access</h3>
      <div className="space-y-3 max-h-[280px] overflow-y-auto">
        {accessLogs.length === 0 && (
          <p className="text-sm text-slate-400 text-center py-8">No recent activity</p>
        )}
        {accessLogs.slice(0, 8).map((log, i) => {
          const config = iconMap[log.scan_type] || iconMap.IN;
          const Icon = config.icon;
          return (
            <div key={log.id || i} className="flex items-center gap-3">
              <div className={cn("p-1.5 rounded-lg", config.color)}>
                <Icon className="w-3.5 h-3.5" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium text-slate-800 truncate">{log.employee_name || log.employee_id}</p>
                <p className="text-xs text-slate-400">{log.scan_type === "IN" ? "Checked in" : "Checked out"}</p>
              </div>
              <span className="text-xs text-slate-400 flex-shrink-0">
                {log.scan_time ? new Date(log.scan_time).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : ""}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
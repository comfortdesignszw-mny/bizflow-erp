import React from "react";
import { Badge } from "@/components/ui/badge";
import { Calendar, User, Flag, Building } from "lucide-react";
import { cn } from "@/lib/utils";

const priorityColors = {
  Low: "bg-slate-100 text-slate-600 border-slate-200",
  Medium: "bg-blue-50 text-blue-700 border-blue-200",
  High: "bg-orange-50 text-orange-700 border-orange-200",
  Critical: "bg-red-50 text-red-700 border-red-200",
};

const priorityDot = {
  Low: "bg-slate-400",
  Medium: "bg-blue-500",
  High: "bg-orange-500",
  Critical: "bg-red-500",
};

export default function TaskCard({ task, onClick }) {
  const isOverdue = task.deadline && new Date(task.deadline) < new Date() && task.status !== "Done";

  return (
    <div
      onClick={() => onClick(task)}
      className="bg-white rounded-xl border border-slate-200 p-3.5 shadow-sm hover:shadow-md hover:border-indigo-200 cursor-pointer transition-all group"
    >
      {/* Priority dot + name */}
      <div className="flex items-start gap-2 mb-2">
        <span className={cn("w-2 h-2 rounded-full flex-shrink-0 mt-1.5", priorityDot[task.priority])} />
        <p className="text-sm font-semibold text-slate-800 leading-snug group-hover:text-indigo-700 transition-colors">
          {task.task_name}
        </p>
      </div>

      {/* Description */}
      {task.description && (
        <p className="text-xs text-slate-500 mb-2 line-clamp-2 ml-4">{task.description}</p>
      )}

      {/* Tags */}
      {task.tags && (
        <div className="flex flex-wrap gap-1 mb-2 ml-4">
          {task.tags.split(",").map((t, i) => (
            <span key={i} className="text-[10px] bg-indigo-50 text-indigo-600 rounded-full px-2 py-0.5 font-medium">
              {t.trim()}
            </span>
          ))}
        </div>
      )}

      {/* Meta */}
      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 ml-4 mt-2">
        {task.department && (
          <span className="flex items-center gap-1 text-[11px] text-slate-500">
            <Building className="w-3 h-3" /> {task.department}
          </span>
        )}
        {task.assigned_employee_name && (
          <span className="flex items-center gap-1 text-[11px] text-slate-500">
            <User className="w-3 h-3" /> {task.assigned_employee_name}
          </span>
        )}
        {task.deadline && (
          <span className={cn("flex items-center gap-1 text-[11px]", isOverdue ? "text-red-500 font-medium" : "text-slate-400")}>
            <Calendar className="w-3 h-3" /> {task.deadline}
          </span>
        )}
      </div>

      {/* Bottom row */}
      <div className="flex items-center justify-between mt-2.5 ml-4">
        <Badge className={cn("text-[10px] px-2 py-0.5 border", priorityColors[task.priority])}>
          {task.priority}
        </Badge>
        {task.project_name && (
          <span className="text-[10px] text-slate-400 truncate max-w-[100px]">{task.project_name}</span>
        )}
      </div>
    </div>
  );
}
import React from "react";
import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { ArrowUpRight, CheckCircle, Clock, AlertCircle } from "lucide-react";
import { cn } from "@/lib/utils";

const statusColors = {
  "To Do": "bg-slate-100 text-slate-600",
  "In Progress": "bg-blue-100 text-blue-700",
  "Review": "bg-amber-100 text-amber-700",
  "Done": "bg-emerald-100 text-emerald-700",
};

export default function DepartmentTaskWidget({ department }) {
  const { data: tasks = [] } = useQuery({
    queryKey: ["tasks-dept", department],
    queryFn: () => base44.entities.Task.filter({ department }, "-created_date", 50),
  });

  const todo = tasks.filter(t => t.status === "To Do").length;
  const inProgress = tasks.filter(t => t.status === "In Progress").length;
  const review = tasks.filter(t => t.status === "Review").length;
  const done = tasks.filter(t => t.status === "Done").length;
  const critical = tasks.filter(t => t.priority === "Critical" && t.status !== "Done").length;

  if (tasks.length === 0) return null;

  return (
    <Card className="border-0 shadow-sm">
      <CardHeader className="pb-2 flex flex-row items-center justify-between">
        <CardTitle className="text-sm font-semibold text-slate-700">
          {department} — Tasks
        </CardTitle>
        <Link to={createPageUrl("Tasks") + `?dept=${encodeURIComponent(department)}`} className="text-xs text-indigo-600 hover:underline flex items-center gap-0.5">
          View all <ArrowUpRight className="w-3 h-3" />
        </Link>
      </CardHeader>
      <CardContent className="space-y-3">
        {/* Counts */}
        <div className="grid grid-cols-4 gap-2">
          {[
            { label: "To Do", count: todo, color: "text-slate-600" },
            { label: "In Prog", count: inProgress, color: "text-blue-600" },
            { label: "Review", count: review, color: "text-amber-600" },
            { label: "Done", count: done, color: "text-emerald-600" },
          ].map(({ label, count, color }) => (
            <div key={label} className="text-center">
              <p className={cn("text-xl font-bold", color)}>{count}</p>
              <p className="text-[10px] text-slate-400">{label}</p>
            </div>
          ))}
        </div>

        {/* Critical alert */}
        {critical > 0 && (
          <div className="flex items-center gap-2 bg-red-50 rounded-lg px-3 py-2">
            <AlertCircle className="w-3.5 h-3.5 text-red-500 flex-shrink-0" />
            <span className="text-xs text-red-600 font-medium">{critical} critical task{critical > 1 ? "s" : ""} need attention</span>
          </div>
        )}

        {/* Recent tasks */}
        <div className="space-y-1.5">
          {tasks.slice(0, 3).map(t => (
            <div key={t.id} className="flex items-center justify-between gap-2">
              <span className="text-xs text-slate-700 truncate flex-1">{t.task_name}</span>
              <Badge className={cn("text-[10px] shrink-0", statusColors[t.status])}>{t.status}</Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Trash2 } from "lucide-react";

const DEPARTMENTS = [
  "Accounting", "Engineering", "Finance", "HR", "IT", "Legal",
  "Marketing", "Operations", "Procurement", "Sales", "Support", "Executive",
];
const PRIORITIES = ["Low", "Medium", "High", "Critical"];
const STATUSES = ["To Do", "In Progress", "Review", "Done"];

const empty = {
  task_name: "", description: "", department: "", project_id: "", project_name: "",
  assigned_employee_id: "", assigned_employee_name: "", reported_by: "",
  priority: "Medium", status: "To Do", deadline: "", tags: "", notes: "",
};

export default function TaskFormModal({ open, onClose, onSave, onDelete, initialTask }) {
  const [form, setForm] = useState(empty);
  const isEdit = !!initialTask?.id;

  useEffect(() => {
    if (open) setForm(initialTask ? { ...empty, ...initialTask } : empty);
  }, [open, initialTask]);

  const { data: projects = [] } = useQuery({
    queryKey: ["projects-picker"],
    queryFn: () => base44.entities.Project.list("-created_date", 100),
  });
  const { data: employees = [] } = useQuery({
    queryKey: ["employees-picker"],
    queryFn: () => base44.entities.Employee.list("-created_date", 300),
  });

  const deptEmployees = form.department
    ? employees.filter(e => e.department === form.department || !form.department)
    : employees;

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSave = () => {
    if (!form.task_name || !form.department) return;
    onSave(form);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Edit Task" : "Create Task"}</DialogTitle>
        </DialogHeader>

        <div className="space-y-3 pt-1">
          <div>
            <label className="text-xs text-slate-500 font-medium">Task Name *</label>
            <Input placeholder="e.g. Fix database schema" value={form.task_name} onChange={e => set("task_name", e.target.value)} />
          </div>

          <div>
            <label className="text-xs text-slate-500 font-medium">Description</label>
            <textarea
              className="w-full text-sm border border-input rounded-md px-3 py-2 min-h-[72px] resize-none focus:outline-none focus:ring-1 focus:ring-ring"
              placeholder="What needs to be done?"
              value={form.description}
              onChange={e => set("description", e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 font-medium">Department *</label>
              <Select value={form.department} onValueChange={v => { set("department", v); set("assigned_employee_id", ""); set("assigned_employee_name", ""); }}>
                <SelectTrigger><SelectValue placeholder="Select department" /></SelectTrigger>
                <SelectContent>{DEPARTMENTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium">Priority</label>
              <Select value={form.priority} onValueChange={v => set("priority", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{PRIORITIES.map(p => <SelectItem key={p} value={p}>{p}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 font-medium">Assign To (Employee)</label>
              <Select value={form.assigned_employee_id} onValueChange={v => {
                const emp = employees.find(e => e.id === v);
                set("assigned_employee_id", v);
                set("assigned_employee_name", emp?.full_name || "");
              }}>
                <SelectTrigger><SelectValue placeholder="Select employee" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="unassigned">— Unassigned —</SelectItem>
                  {deptEmployees.map(e => <SelectItem key={e.id} value={e.id}>{e.full_name} ({e.job_title})</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium">Status</label>
              <Select value={form.status} onValueChange={v => set("status", v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>{STATUSES.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 font-medium">Linked Project</label>
              <Select value={form.project_id} onValueChange={v => {
                const p = projects.find(x => x.id === v);
                set("project_id", v);
                set("project_name", p?.project_name || "");
              }}>
                <SelectTrigger><SelectValue placeholder="No project" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">— None —</SelectItem>
                  {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.project_name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium">Deadline</label>
              <Input type="date" value={form.deadline} onChange={e => set("deadline", e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-slate-500 font-medium">Reported By</label>
              <Input placeholder="Your name" value={form.reported_by} onChange={e => set("reported_by", e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-slate-500 font-medium">Tags (comma-separated)</label>
              <Input placeholder="e.g. urgent, backend" value={form.tags} onChange={e => set("tags", e.target.value)} />
            </div>
          </div>

          <div>
            <label className="text-xs text-slate-500 font-medium">Notes</label>
            <textarea
              className="w-full text-sm border border-input rounded-md px-3 py-2 min-h-[56px] resize-none focus:outline-none focus:ring-1 focus:ring-ring"
              placeholder="Additional notes..."
              value={form.notes}
              onChange={e => set("notes", e.target.value)}
            />
          </div>

          <div className="flex gap-2 pt-1">
            {isEdit && (
              <Button variant="outline" className="border-red-200 text-red-600 hover:bg-red-50" onClick={() => onDelete(initialTask.id)}>
                <Trash2 className="w-4 h-4 mr-1.5" /> Delete
              </Button>
            )}
            <Button className="flex-1 bg-indigo-600 hover:bg-indigo-700" onClick={handleSave}>
              {isEdit ? "Save Changes" : "Create Task"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
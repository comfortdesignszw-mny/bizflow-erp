import React, { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { createPageUrl } from "@/utils";
import { Copy, Check, Share2, MessageCircle, Linkedin, Mail, Twitter, Facebook, Link2 } from "lucide-react";
import { format } from "date-fns";
import { useCompanyProfile } from "@/components/brand/useCompanyProfile";
import CompanyLetterhead from "@/components/brand/CompanyLetterhead";

export default function ShareVacancyModal({ vacancy, open, onClose }) {
  const [copied, setCopied] = useState(false);
  const [copiedText, setCopiedText] = useState(false);
  const { company } = useCompanyProfile();

  if (!vacancy) return null;

  const companyName = company?.company_name || "Our Company";
  const applyUrl = `${window.location.origin}${createPageUrl(`Apply?vacancy=${vacancy.id}`)}`;

  const postText = `🚀 ${companyName} is Hiring: ${vacancy.job_title}
📂 Department: ${vacancy.department}${vacancy.salary_range ? `\n💰 Salary: ${vacancy.salary_range}` : ""}${vacancy.experience_required ? `\n📋 Experience: ${vacancy.experience_required}` : ""}${vacancy.skills_required ? `\n🛠 Skills: ${vacancy.skills_required}` : ""}${vacancy.deadline ? `\n⏳ Apply by: ${format(new Date(vacancy.deadline), "MMMM d, yyyy")}` : ""}

${vacancy.description ? vacancy.description + "\n\n" : ""}${company?.motto ? `"${company.motto}"\n\n` : ""}👉 Apply here: ${applyUrl}
${company?.website ? `🌐 ${company.website}` : ""}
#Hiring #JobOpening #${vacancy.department?.replace(/\s/g, "")} #Careers`;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(applyUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleCopyPost = () => {
    navigator.clipboard.writeText(postText);
    setCopiedText(true);
    setTimeout(() => setCopiedText(false), 2000);
  };

  const encodedText = encodeURIComponent(postText);
  const encodedUrl = encodeURIComponent(applyUrl);
  const encodedTitle = encodeURIComponent(`${companyName} is Hiring: ${vacancy.job_title}`);

  const platforms = [
    { name: "WhatsApp", icon: MessageCircle, color: "bg-emerald-500 hover:bg-emerald-600", url: `https://wa.me/?text=${encodedText}` },
    { name: "LinkedIn", icon: Linkedin, color: "bg-sky-700 hover:bg-sky-800", url: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}&summary=${encodedText}` },
    { name: "Twitter/X", icon: Twitter, color: "bg-slate-900 hover:bg-slate-800", url: `https://twitter.com/intent/tweet?text=${encodedText}` },
    { name: "Facebook", icon: Facebook, color: "bg-blue-600 hover:bg-blue-700", url: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodeURIComponent(`${companyName} is Hiring: ${vacancy.job_title}`)}` },
    { name: "Email", icon: Mail, color: "bg-amber-500 hover:bg-amber-600", url: `mailto:?subject=${encodedTitle}&body=${encodedText}` },
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="w-4 h-4 text-cyan-600" /> Share Vacancy
          </DialogTitle>
        </DialogHeader>

        {/* Branded letterhead */}
        <CompanyLetterhead company={company} variant="full" className="rounded-xl overflow-hidden" />

        {/* Job preview */}
        <div className="bg-cyan-50 rounded-xl p-4 border border-cyan-200">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="font-semibold text-slate-900 text-sm">{vacancy.job_title}</p>
              <p className="text-xs text-slate-500 mt-0.5">{vacancy.department}</p>
            </div>
            <Badge className="bg-cyan-100 text-cyan-700 border-cyan-200 text-xs flex-shrink-0">Open</Badge>
          </div>
          {vacancy.salary_range && <p className="text-xs text-slate-500 mt-2">💰 {vacancy.salary_range}</p>}
          {vacancy.deadline && <p className="text-xs text-slate-500">⏳ Deadline: {format(new Date(vacancy.deadline), "MMM d, yyyy")}</p>}
        </div>

        {/* Application link */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Application Link</p>
          <div className="flex gap-2">
            <Input value={applyUrl} readOnly className="h-9 text-xs text-slate-600 bg-slate-50 flex-1" />
            <Button size="sm" variant="outline" onClick={handleCopyLink} className="h-9 gap-1 flex-shrink-0 border-cyan-300 text-cyan-700 hover:bg-cyan-50">
              {copied ? <><Check className="w-3.5 h-3.5 text-emerald-600" /> Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy</>}
            </Button>
          </div>
          <p className="text-xs text-slate-400 flex items-center gap-1">
            <Link2 className="w-3 h-3" /> Clicking this link takes applicants directly to the application form
          </p>
        </div>

        {/* Share platforms */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Share to Platform</p>
          <div className="grid grid-cols-2 gap-2">
            {platforms.map((p) => (
              <a key={p.name} href={p.url} target="_blank" rel="noopener noreferrer">
                <Button className={`w-full h-10 text-xs gap-2 text-white ${p.color}`}>
                  <p.icon className="w-4 h-4" /> {p.name}
                </Button>
              </a>
            ))}
          </div>
        </div>

        {/* Copy full post */}
        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-600 uppercase tracking-wider">Full Post Text</p>
          <div className="bg-slate-50 rounded-xl p-3 border border-slate-200 max-h-40 overflow-y-auto">
            <pre className="text-xs text-slate-600 whitespace-pre-wrap font-sans leading-relaxed">{postText}</pre>
          </div>
          <Button variant="outline" size="sm" onClick={handleCopyPost} className="w-full gap-2 h-9 border-cyan-300 text-cyan-700 hover:bg-cyan-50">
            {copiedText ? <><Check className="w-3.5 h-3.5 text-emerald-600" /> Post Copied!</> : <><Copy className="w-3.5 h-3.5" /> Copy Full Post</>}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
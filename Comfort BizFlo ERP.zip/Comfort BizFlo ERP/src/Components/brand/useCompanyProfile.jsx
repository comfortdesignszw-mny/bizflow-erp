import { useQuery } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";

export function useCompanyProfile() {
  const { data, isLoading } = useQuery({
    queryKey: ["company-profile"],
    queryFn: () => base44.entities.CompanyProfile.list("-created_date", 1),
    staleTime: 60000,
  });
  return { company: data?.[0] || null, isLoading };
}
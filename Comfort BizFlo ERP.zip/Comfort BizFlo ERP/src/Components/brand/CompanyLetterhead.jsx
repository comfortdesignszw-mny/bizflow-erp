mport React from "react";
import { Globe, Mail, Phone, MapPin } from "lucide-react";

/**
 * Reusable branded letterhead / header.
 * variant: "full" (for reports/docs) | "compact" (for modals/cards)
 */
export default function CompanyLetterhead({ company, variant = "full", className = "" }) {
  const name = company?.company_name || "Your Company";
  const motto = company?.motto || "";

  if (variant === "compact") {
    return (
      <div className={`flex items-center gap-3 ${className}`}>
        {company?.logo_url ? (
          <img src={company.logo_url} alt={name} className="h-10 w-10 rounded-lg object-contain border border-cyan-200" />
        ) : (
          <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
            {name.charAt(0).toUpperCase()}
          </div>
        )}
        <div>
          <p className="font-bold text-slate-900 text-sm leading-tight">{name}</p>
          {motto && <p className="text-xs text-cyan-600 italic">{motto}</p>}
        </div>
      </div>
    );
  }

  return (
    <div className={`w-full ${className}`}>
      {/* Cyan-to-blue gradient header bar */}
      <div className="bg-gradient-to-r from-cyan-500 to-blue-700 px-6 py-4 flex items-center justify-between rounded-t-xl">
        <div className="flex items-center gap-4">
          {company?.logo_url ? (
            <img src={company.logo_url} alt={name} className="h-14 w-14 rounded-xl object-contain bg-white p-1 shadow" />
          ) : (
            <div className="h-14 w-14 rounded-xl bg-white/20 border border-white/40 flex items-center justify-center text-white font-black text-2xl shadow">
              {name.charAt(0).toUpperCase()}
            </div>
          )}
          <div>
            <h1 className="text-white font-black text-xl tracking-wide leading-tight">{name}</h1>
            {motto && <p className="text-cyan-100 text-xs italic mt-0.5">{motto}</p>}
          </div>
        </div>
        <div className="hidden sm:flex flex-col items-end gap-1">
          {company?.website && (
            <span className="text-cyan-100 text-xs flex items-center gap-1">
              <Globe className="w-3 h-3" />{company.website}
            </span>
          )}
          {company?.email && (
            <span className="text-cyan-100 text-xs flex items-center gap-1">
              <Mail className="w-3 h-3" />{company.email}
            </span>
          )}
          {company?.phone && (
            <span className="text-cyan-100 text-xs flex items-center gap-1">
              <Phone className="w-3 h-3" />{company.phone}
            </span>
          )}
        </div>
      </div>
      {/* White info bar */}
      {company?.address && (
        <div className="bg-blue-50 border-x border-b border-blue-100 px-6 py-1.5 flex items-center gap-2 rounded-b-sm">
          <MapPin className="w-3 h-3 text-blue-400 flex-shrink-0" />
          <p className="text-xs text-blue-600">{company.address}</p>
        </div>
      )}
      {/* Bottom accent line */}
      <div className="h-0.5 bg-gradient-to-r from-cyan-400 via-blue-500 to-blue-700" />
    </div>
  );
}
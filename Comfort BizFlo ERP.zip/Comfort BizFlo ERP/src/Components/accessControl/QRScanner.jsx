mport React, { useEffect, useRef, useState } from "react";
import { Html5Qrcode } from "html5-qrcode";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { Camera, CameraOff, CheckCircle2, XCircle, Loader2 } from "lucide-react";
import { base44 } from "@/api/base44Client";

const LOCATIONS = ["Main Entrance", "Back Entrance", "Office Floor", "Server Room", "Conference Room", "Parking"];

export default function QRScanner({ employees, onScanned, onClose }) {
  const scannerRef = useRef(null);
  const html5QrRef = useRef(null);
  const [scanning, setScanning] = useState(false);
  const [scanType, setScanType] = useState("IN");
  const [location, setLocation] = useState("Main Entrance");
  const [result, setResult] = useState(null); // {success, employee, message}
  const [processing, setProcessing] = useState(false);
  const [cameraError, setCameraError] = useState(null);

  const startScanner = async () => {
    setCameraError(null);
    setResult(null);
    try {
      html5QrRef.current = new Html5Qrcode("qr-reader");
      await html5QrRef.current.start(
        { facingMode: "environment" },
        { fps: 10, qrbox: { width: 220, height: 220 } },
        (decodedText) => handleQRResult(decodedText),
        () => {}
      );
      setScanning(true);
    } catch (err) {
      setCameraError("Camera access denied or not available. Please allow camera access and try again.");
    }
  };

  const stopScanner = async () => {
    if (html5QrRef.current && scanning) {
      await html5QrRef.current.stop();
      html5QrRef.current.clear();
    }
    setScanning(false);
  };

  useEffect(() => {
    return () => {
      if (html5QrRef.current && scanning) {
        html5QrRef.current.stop().catch(() => {});
      }
    };
  }, [scanning]);

  const handleQRResult = async (decodedText) => {
    if (processing) return;
    setProcessing(true);
    await stopScanner();

    // QR codes contain JSON like: {"employee_id":"EMP-123","full_name":"John Doe",...}
    // or plain employee_id string
    let employeeId = decodedText;
    let parsedData = null;
    try {
      parsedData = JSON.parse(decodedText);
      employeeId = parsedData.employee_id;
    } catch {
      // plain string — use as-is
    }

    const emp = employees.find(e => e.employee_id === employeeId || e.id === employeeId);

    if (!emp) {
      setResult({ success: false, message: "Employee not found in system. QR code: " + employeeId });
      setProcessing(false);
      return;
    }

    try {
      await base44.entities.AccessLog.create({
        employee_id: emp.employee_id,
        employee_name: emp.full_name,
        scan_type: scanType,
        scan_time: new Date().toISOString(),
        location,
        device_id: "CAMERA-SCANNER",
      });

      // Auto attendance
      const today = new Date().toISOString().split("T")[0];
      if (scanType === "IN") {
        const existing = await base44.entities.Attendance.filter({ employee_id: emp.employee_id, date: today });
        if (existing.length === 0) {
          const now = new Date();
          const timeIn = now.toTimeString().split(" ")[0].slice(0, 5);
          await base44.entities.Attendance.create({
            employee_id: emp.employee_id,
            employee_name: emp.full_name,
            date: today,
            time_in: timeIn,
            status: now.getHours() >= 9 ? "Late" : "Present",
          });
        }
      } else {
        const records = await base44.entities.Attendance.filter({ employee_id: emp.employee_id, date: today });
        if (records.length > 0) {
          const now = new Date();
          const timeOut = now.toTimeString().split(" ")[0].slice(0, 5);
          const timeIn = records[0].time_in;
          let totalHours = 0;
          if (timeIn) {
            const [h1, m1] = timeIn.split(":").map(Number);
            const [h2, m2] = timeOut.split(":").map(Number);
            totalHours = Math.round(((h2 * 60 + m2) - (h1 * 60 + m1)) / 60 * 10) / 10;
          }
          await base44.entities.Attendance.update(records[0].id, {
            time_out: timeOut,
            total_hours: totalHours,
            overtime_hours: Math.max(0, totalHours - 8),
          });
        }
      }

      setResult({ success: true, employee: emp, scanType });
      onScanned();
    } catch (err) {
      setResult({ success: false, message: "Failed to record scan. Please try again." });
    }
    setProcessing(false);
  };

  const reset = () => {
    setResult(null);
    setCameraError(null);
    startScanner();
  };

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs">Scan Type</Label>
          <Select value={scanType} onValueChange={setScanType} disabled={scanning}>
            <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="IN">✅ Check In</SelectItem>
              <SelectItem value="OUT">🚪 Check Out</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">Location</Label>
          <Select value={location} onValueChange={setLocation} disabled={scanning}>
            <SelectTrigger className="h-9 text-sm"><SelectValue /></SelectTrigger>
            <SelectContent>
              {LOCATIONS.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Camera viewer */}
      {!result && (
        <div className="relative bg-slate-900 rounded-2xl overflow-hidden" style={{ minHeight: 280 }}>
          <div id="qr-reader" className="w-full" />
          {!scanning && !cameraError && (
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
              <Camera className="w-10 h-10 text-slate-400" />
              <p className="text-sm text-slate-400">Camera is off</p>
            </div>
          )}
          {scanning && (
            <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
              <div className="w-52 h-52 border-2 border-indigo-400 rounded-xl opacity-60 animate-pulse" />
            </div>
          )}
          {processing && (
            <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
              <Loader2 className="w-8 h-8 animate-spin text-white" />
            </div>
          )}
        </div>
      )}

      {/* Error */}
      {cameraError && (
        <div className="bg-rose-50 border border-rose-200 rounded-xl p-4 text-center">
          <XCircle className="w-8 h-8 text-rose-400 mx-auto mb-2" />
          <p className="text-sm text-rose-600">{cameraError}</p>
        </div>
      )}

      {/* Scan result */}
      {result && (
        <div className={`rounded-xl p-5 text-center border ${result.success ? "bg-emerald-50 border-emerald-200" : "bg-rose-50 border-rose-200"}`}>
          {result.success ? (
            <>
              <CheckCircle2 className="w-10 h-10 text-emerald-500 mx-auto mb-2" />
              <p className="font-semibold text-slate-900">{result.employee.full_name}</p>
              <p className="text-xs text-slate-500 mt-0.5">{result.employee.job_title} · {result.employee.department}</p>
              <div className={`inline-block mt-2 px-3 py-1 rounded-full text-xs font-medium ${result.scanType === "IN" ? "bg-emerald-100 text-emerald-700" : "bg-amber-100 text-amber-700"}`}>
                {result.scanType === "IN" ? "✅ Checked In" : "🚪 Checked Out"} · {location}
              </div>
            </>
          ) : (
            <>
              <XCircle className="w-10 h-10 text-rose-400 mx-auto mb-2" />
              <p className="text-sm text-rose-600">{result.message}</p>
            </>
          )}
        </div>
      )}

      {/* Buttons */}
      <div className="flex gap-2">
        {!scanning && !result && (
          <Button onClick={startScanner} className="flex-1 bg-indigo-600 hover:bg-indigo-700 gap-2">
            <Camera className="w-4 h-4" /> Start Camera Scanner
          </Button>
        )}
        {scanning && (
          <Button onClick={stopScanner} variant="outline" className="flex-1 gap-2 text-rose-600 border-rose-200">
            <CameraOff className="w-4 h-4" /> Stop Camera
          </Button>
        )}
        {result && (
          <Button onClick={reset} className="flex-1 bg-indigo-600 hover:bg-indigo-700 gap-2">
            <Camera className="w-4 h-4" /> Scan Another
          </Button>
        )}
        <Button variant="outline" onClick={() => { stopScanner(); onClose(); }} className="px-4">
          Close
        </Button>
      </div>
    </div>
  );
}
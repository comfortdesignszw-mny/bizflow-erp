import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Loader2, Copy, CheckCheck, Sparkles, MessageSquare } from "lucide-react";

const categoryColors = {
  Technical: "bg-blue-50 text-blue-700 border-blue-200",
  Behavioral: "bg-violet-50 text-violet-700 border-violet-200",
  Situational: "bg-amber-50 text-amber-700 border-amber-200",
  Cultural: "bg-emerald-50 text-emerald-700 border-emerald-200",
};

export default function InterviewQuestionsModal({ application, vacancy, open, onClose }) {
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState(null);
  const [copied, setCopied] = useState(false);

  const generate = async () => {
    setLoading(true);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate tailored interview questions for the following candidate and role.

Role: ${vacancy?.job_title || application.vacancy_title}
Department: ${vacancy?.department || ""}
Required Skills: ${vacancy?.skills_required || "not specified"}
Required Experience: ${vacancy?.experience_required || "not specified"}

Candidate: ${application.candidate_name}
Candidate Skills: ${application.skills || "not specified"}
Experience: ${application.experience_years ? `${application.experience_years} years` : "not specified"}
Education: ${application.education || "not specified"}
Previous Companies: ${application.previous_companies || "not specified"}
Match Score: ${application.match_score != null ? `${application.match_score}%` : "unknown"}

Generate 12 targeted interview questions, categorized as:
- Technical (4 questions: test role-specific skills and knowledge)
- Behavioral (3 questions: past experiences, STAR format)
- Situational (3 questions: hypothetical scenarios relevant to the role)
- Cultural (2 questions: values and teamwork fit)

Each question should be specific to this candidate's background and the role requirements.`,
      response_json_schema: {
        type: "object",
        properties: {
          questions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                category: { type: "string" },
                question: { type: "string" },
                what_to_look_for: { type: "string" },
              },
            },
          },
          candidate_summary: { type: "string" },
        },
      },
    });
    setQuestions(result);
    setLoading(false);
  };

  const handleCopy = () => {
    const text = questions.questions.map((q, i) => `${i + 1}. [${q.category}] ${q.question}\n   → Look for: ${q.what_to_look_for}`).join("\n\n");
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MessageSquare className="w-4 h-4 text-violet-500" />
            AI Interview Questions — {application?.candidate_name}
          </DialogTitle>
        </DialogHeader>

        {!questions && !loading && (
          <div className="text-center py-12 space-y-4">
            <div className="w-16 h-16 rounded-2xl bg-violet-50 flex items-center justify-center mx-auto">
              <Sparkles className="w-8 h-8 text-violet-500" />
            </div>
            <div>
              <p className="text-sm font-medium text-slate-800">Generate Tailored Interview Questions</p>
              <p className="text-xs text-slate-500 mt-1">AI will create questions based on {application?.candidate_name}'s profile and the {application?.vacancy_title} role</p>
            </div>
            <Button onClick={generate} className="bg-violet-600 hover:bg-violet-700 gap-2">
              <Sparkles className="w-4 h-4" /> Generate Questions
            </Button>
          </div>
        )}

        {loading && (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-violet-500" />
            <p className="text-sm text-slate-500">Crafting tailored interview questions...</p>
          </div>
        )}

        {questions && (
          <div className="space-y-4">
            {/* Candidate Summary */}
            <div className="bg-slate-50 rounded-xl p-3 border border-slate-200">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Candidate AI Summary</p>
              <p className="text-sm text-slate-700">{questions.candidate_summary}</p>
            </div>

            {/* Questions grouped by category */}
            {["Technical", "Behavioral", "Situational", "Cultural"].map((cat) => {
              const catQs = questions.questions?.filter(q => q.category === cat) || [];
              if (catQs.length === 0) return null;
              return (
                <div key={cat}>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="outline" className={categoryColors[cat]}>{cat}</Badge>
                  </div>
                  <div className="space-y-2">
                    {catQs.map((q, i) => (
                      <div key={i} className="bg-white border border-slate-200 rounded-xl p-3">
                        <p className="text-sm font-medium text-slate-800">{q.question}</p>
                        {q.what_to_look_for && (
                          <p className="text-xs text-slate-500 mt-1.5">
                            <span className="font-medium text-slate-600">Look for: </span>{q.what_to_look_for}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}

            {/* Actions */}
            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <Button variant="outline" onClick={handleCopy} className="gap-2 rounded-xl">
                {copied ? <CheckCheck className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                {copied ? "Copied!" : "Copy All"}
              </Button>
              <Button variant="outline" onClick={generate} className="gap-2 rounded-xl">
                <Sparkles className="w-4 h-4" /> Regenerate
              </Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
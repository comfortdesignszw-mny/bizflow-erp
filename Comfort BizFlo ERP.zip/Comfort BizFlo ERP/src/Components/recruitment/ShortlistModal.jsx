import React, { useState } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Sparkles, Star, ThumbsUp, ThumbsDown, Users } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function ShortlistModal({ applications, vacancies, open, onClose }) {
  const [selectedVacancy, setSelectedVacancy] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [promoting, setPromoting] = useState(false);
  const queryClient = useQueryClient();

  const vacancy = vacancies.find(v => v.id === selectedVacancy);
  const vacancyApps = applications.filter(a => a.vacancy_id === selectedVacancy || a.vacancy_title === vacancy?.job_title);

  const generateShortlist = async () => {
    if (!selectedVacancy || vacancyApps.length === 0) return;
    setLoading(true);

    const appSummaries = vacancyApps.map((a, i) => ({
      index: i,
      id: a.id,
      name: a.candidate_name,
      match_score: a.match_score,
      experience_years: a.experience_years,
      skills: a.skills,
      education: a.education,
      stage: a.pipeline_stage,
    }));

    const res = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an expert HR recruiter. Analyze these candidates for the role of ${vacancy.job_title} in ${vacancy.department}.

Job Requirements:
- Required Skills: ${vacancy.skills_required || "not specified"}
- Required Experience: ${vacancy.experience_required || "not specified"}
- Salary Range: ${vacancy.salary_range || "not specified"}
- Description: ${vacancy.description || "not specified"}

Candidates (${vacancyApps.length} total):
${JSON.stringify(appSummaries, null, 2)}

Based on match scores, experience, skills alignment, and overall profile:
1. Recommend the TOP candidates to shortlist (max 5, only those truly qualified)
2. Briefly explain why each recommended candidate is a good fit
3. Identify any candidates who should be rejected and why
4. Provide an overall recruitment summary`,
      response_json_schema: {
        type: "object",
        properties: {
          shortlist: {
            type: "array",
            items: {
              type: "object",
              properties: {
                candidate_id: { type: "string" },
                candidate_name: { type: "string" },
                reason: { type: "string" },
                strengths: { type: "array", items: { type: "string" } },
                concerns: { type: "string" },
              },
            },
          },
          reject_suggestions: {
            type: "array",
            items: {
              type: "object",
              properties: {
                candidate_name: { type: "string" },
                reason: { type: "string" },
              },
            },
          },
          summary: { type: "string" },
        },
      },
    });
    setResult(res);
    setLoading(false);
  };

  const applyShortlist = async () => {
    setPromoting(true);
    for (const rec of result.shortlist) {
      const app = vacancyApps.find(a => a.candidate_name === rec.candidate_name);
      if (app && app.pipeline_stage === "Applied") {
        await base44.entities.Application.update(app.id, { pipeline_stage: "Shortlisted" });
      }
    }
    queryClient.invalidateQueries({ queryKey: ["applications"] });
    setPromoting(false);
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-4 h-4 text-emerald-500" />
            AI Shortlist Generator
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-medium text-slate-600">Select Vacancy</label>
            <Select value={selectedVacancy} onValueChange={(v) => { setSelectedVacancy(v); setResult(null); }}>
              <SelectTrigger className="h-9 text-sm">
                <SelectValue placeholder="Choose a vacancy to analyze" />
              </SelectTrigger>
              <SelectContent>
                {vacancies.map(v => (
                  <SelectItem key={v.id} value={v.id}>{v.job_title} — {v.department}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedVacancy && (
              <p className="text-xs text-slate-500">{vacancyApps.length} application(s) found for this position</p>
            )}
          </div>

          {selectedVacancy && !result && !loading && (
            <Button
              onClick={generateShortlist}
              disabled={vacancyApps.length === 0}
              className="w-full bg-emerald-600 hover:bg-emerald-700 gap-2"
            >
              <Sparkles className="w-4 h-4" />
              {vacancyApps.length === 0 ? "No applications for this vacancy" : `Analyze ${vacancyApps.length} Candidates`}
            </Button>
          )}

          {loading && (
            <div className="flex flex-col items-center justify-center py-12 gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-emerald-500" />
              <p className="text-sm text-slate-500">AI is analyzing all candidates...</p>
            </div>
          )}

          {result && (
            <div className="space-y-5">
              {/* Summary */}
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-200">
                <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">AI Recruitment Summary</p>
                <p className="text-sm text-slate-700">{result.summary}</p>
              </div>

              {/* Shortlist */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <ThumbsUp className="w-4 h-4 text-emerald-600" />
                  <p className="text-sm font-semibold text-slate-800">Recommended Shortlist ({result.shortlist?.length || 0})</p>
                </div>
                <div className="space-y-3">
                  {result.shortlist?.map((rec, i) => (
                    <div key={i} className="bg-emerald-50 border border-emerald-200 rounded-xl p-3">
                      <div className="flex items-center justify-between mb-1">
                        <p className="text-sm font-semibold text-slate-800 flex items-center gap-1">
                          <Star className="w-3.5 h-3.5 text-amber-500 fill-amber-400" />
                          {rec.candidate_name}
                        </p>
                        <Badge className="bg-emerald-100 text-emerald-700 border-emerald-200 text-xs">#{i + 1} Pick</Badge>
                      </div>
                      <p className="text-xs text-slate-600 mb-2">{rec.reason}</p>
                      {rec.strengths?.length > 0 && (
                        <div className="flex flex-wrap gap-1">
                          {rec.strengths.map((s, j) => (
                            <Badge key={j} variant="outline" className="text-xs bg-white text-emerald-700 border-emerald-300">{s}</Badge>
                          ))}
                        </div>
                      )}
                      {rec.concerns && (
                        <p className="text-xs text-amber-600 mt-1.5">⚠ {rec.concerns}</p>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Rejections */}
              {result.reject_suggestions?.length > 0 && (
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <ThumbsDown className="w-4 h-4 text-rose-500" />
                    <p className="text-sm font-semibold text-slate-800">Not Recommended ({result.reject_suggestions.length})</p>
                  </div>
                  <div className="space-y-2">
                    {result.reject_suggestions.map((r, i) => (
                      <div key={i} className="bg-rose-50 border border-rose-200 rounded-xl p-3">
                        <p className="text-sm font-medium text-slate-800">{r.candidate_name}</p>
                        <p className="text-xs text-slate-500 mt-0.5">{r.reason}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-2 pt-2 border-t border-slate-100">
                <Button variant="outline" onClick={generateShortlist} className="gap-2 rounded-xl">
                  <Sparkles className="w-4 h-4" /> Re-analyze
                </Button>
                {result.shortlist?.length > 0 && (
                  <Button
                    onClick={applyShortlist}
                    disabled={promoting}
                    className="gap-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 ml-auto"
                  >
                    {promoting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ThumbsUp className="w-4 h-4" />}
                    {promoting ? "Applying..." : "Apply Shortlist"}
                  </Button>
                )}
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
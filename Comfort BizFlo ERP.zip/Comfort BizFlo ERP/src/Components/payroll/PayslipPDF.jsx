import { useCompanyProfile } from "@/components/brand/useCompanyProfile";
import jsPDF from "jspdf";

// Helper to draw a rounded rect
function roundRect(doc, x, y, w, h, r) {
  const k = 0.5523;
  doc.lines(
    [
      [w - 2 * r, 0],
      [r * k, 0, r, r - r * k, r, r],
      [0, h - 2 * r],
      [0, r * k, -(r - r * k), r, -r, r],
      [-(w - 2 * r), 0],
      [-r * k, 0, -r, -(r - r * k), -r, -r],
      [0, -(h - 2 * r)],
      [0, -r * k, r - r * k, -r, r, -r],
    ],
    x + r, y, [1, 1], "FD"
  );
}

export function generatePayslipPDF(payroll, company) {
  const doc = new jsPDF({ unit: "mm", format: "a4" });
  const W = 210;
  const companyName = company?.company_name || "BizOps ERP";
  const motto = company?.motto || "";

  // ── Header gradient band (simulated with filled rect) ──
  doc.setFillColor(6, 182, 212); // cyan-500
  doc.rect(0, 0, W, 40, "F");
  doc.setFillColor(29, 78, 216); // blue-700
  doc.rect(0, 30, W, 10, "F");

  // Company name
  doc.setFont("helvetica", "bold");
  doc.setFontSize(18);
  doc.setTextColor(255, 255, 255);
  doc.text(companyName.toUpperCase(), W / 2, 16, { align: "center" });

  if (motto) {
    doc.setFont("helvetica", "italic");
    doc.setFontSize(9);
    doc.setTextColor(220, 245, 255);
    doc.text(motto, W / 2, 23, { align: "center" });
  }

  doc.setFont("helvetica", "bold");
  doc.setFontSize(11);
  doc.setTextColor(255, 255, 255);
  doc.text("EMPLOYEE PAYSLIP", W / 2, 35, { align: "center" });

  // ── Contact strip ──
  doc.setFillColor(236, 254, 255); // cyan-50
  doc.rect(0, 40, W, 10, "F");
  doc.setFont("helvetica", "normal");
  doc.setFontSize(7.5);
  doc.setTextColor(8, 145, 178); // cyan-600
  const contactParts = [
    company?.email && `✉ ${company.email}`,
    company?.phone && `✆ ${company.phone}`,
    company?.website && `🌐 ${company.website}`,
    company?.address && `📍 ${company.address}`,
  ].filter(Boolean);
  doc.text(contactParts.join("   |   "), W / 2, 46, { align: "center" });

  // ── Month badge ──
  doc.setFillColor(14, 116, 144); // cyan-700
  doc.roundedRect(14, 53, 50, 10, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(9);
  doc.setTextColor(255, 255, 255);
  doc.text(`PAY PERIOD: ${payroll.month}`, 39, 59.5, { align: "center" });

  if (payroll.payment_date) {
    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    doc.setTextColor(100, 116, 139);
    doc.text(`Payment Date: ${payroll.payment_date}`, W - 14, 59.5, { align: "right" });
  }

  // ── Employee Details box ──
  doc.setFillColor(248, 250, 252);
  doc.setDrawColor(226, 232, 240);
  doc.roundedRect(14, 67, W - 28, 34, 3, 3, "FD");

  doc.setFont("helvetica", "bold");
  doc.setFontSize(8);
  doc.setTextColor(8, 145, 178);
  doc.text("EMPLOYEE INFORMATION", 20, 74);

  doc.setDrawColor(6, 182, 212);
  doc.setLineWidth(0.4);
  doc.line(14, 76, W - 14, 76);

  const empFields = [
    ["Employee Name", payroll.employee_name || "—"],
    ["Employee ID", payroll.employee_id || "—"],
    ["Department", payroll.department || "—"],
    ["Job Title", payroll.job_title || "—"],
  ];

  const col1X = 20, col2X = 65, col3X = 118, col4X = 163;
  empFields.forEach((field, i) => {
    const col = i < 2 ? (i === 0 ? col1X : col3X) : (i === 2 ? col1X : col3X);
    const row = i < 2 ? 83 : 93;
    doc.setFont("helvetica", "normal");
    doc.setFontSize(7.5);
    doc.setTextColor(148, 163, 184);
    doc.text(field[0].toUpperCase(), col, row - 5);
    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(String(field[1]), col, row);
  });

  // ── Earnings & Deductions table ──
  const tableTop = 107;

  // Table header row
  doc.setFillColor(6, 182, 212);
  doc.roundedRect(14, tableTop, W - 28, 9, 2, 2, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(8.5);
  doc.setTextColor(255, 255, 255);
  doc.text("DESCRIPTION", 20, tableTop + 6);
  doc.text("AMOUNT (USD)", W - 20, tableTop + 6, { align: "right" });
  doc.text("TYPE", W / 2, tableTop + 6, { align: "center" });

  const rows = [
    { label: "Basic Salary", amount: payroll.basic_salary || 0, type: "Earning", positive: true },
    { label: "Overtime Pay", amount: payroll.overtime_pay || 0, type: "Earning", positive: true },
    { label: "Allowances", amount: payroll.allowances || 0, type: "Earning", positive: true },
    { label: "Deductions", amount: payroll.deductions || 0, type: "Deduction", positive: false },
    { label: "Tax (PAYE)", amount: payroll.tax || 0, type: "Deduction", positive: false },
  ];

  let rowY = tableTop + 11;
  rows.forEach((row, i) => {
    if (i % 2 === 0) {
      doc.setFillColor(240, 253, 255);
      doc.rect(14, rowY - 3.5, W - 28, 9, "F");
    }
    doc.setFont("helvetica", "normal");
    doc.setFontSize(9);
    doc.setTextColor(15, 23, 42);
    doc.text(row.label, 20, rowY + 2);

    doc.setFont("helvetica", "normal");
    doc.setFontSize(8);
    if (row.positive) { doc.setTextColor(5, 150, 105); } else { doc.setTextColor(225, 29, 72); }
    doc.text(row.type, W / 2, rowY + 2, { align: "center" });

    doc.setFont("helvetica", "bold");
    doc.setFontSize(9);
    if (row.positive) { doc.setTextColor(5, 150, 105); } else { doc.setTextColor(225, 29, 72); }
    const sign = row.positive ? "+" : "-";
    doc.text(`${sign} $${row.amount.toLocaleString("en-US", { minimumFractionDigits: 2 })}`, W - 20, rowY + 2, { align: "right" });

    rowY += 10;
  });

  // Divider
  doc.setDrawColor(6, 182, 212);
  doc.setLineWidth(0.5);
  doc.line(14, rowY + 1, W - 14, rowY + 1);

  // ── Net Salary box ──
  const netY = rowY + 5;
  doc.setFillColor(14, 116, 144);
  doc.roundedRect(14, netY, W - 28, 16, 3, 3, "F");
  doc.setFont("helvetica", "bold");
  doc.setFontSize(10);
  doc.setTextColor(255, 255, 255);
  doc.text("NET SALARY", 22, netY + 10);
  doc.setFontSize(14);
  doc.text(`$${(payroll.net_salary || 0).toLocaleString("en-US", { minimumFractionDigits: 2 })}`, W - 20, netY + 10, { align: "right" });

  // ── Status badge ──
  const statusColors = {
    Paid: [5, 150, 105],
    Pending: [217, 119, 6],
    Failed: [220, 38, 38],
  };
  const sc = statusColors[payroll.payment_status] || [100, 116, 139];
  doc.setFillColor(sc[0], sc[1], sc[2]);
  doc.roundedRect(14, netY + 20, 35, 8, 2, 2, "F");
  doc.setFontSize(8);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(255, 255, 255);
  doc.text((payroll.payment_status || "Pending").toUpperCase(), 31.5, netY + 25.5, { align: "center" });

  // ── Footer ──
  const footerY = 270;
  doc.setDrawColor(6, 182, 212);
  doc.setLineWidth(0.3);
  doc.line(14, footerY, W - 14, footerY);
  doc.setFont("helvetica", "italic");
  doc.setFontSize(7.5);
  doc.setTextColor(148, 163, 184);
  doc.text("This payslip is computer generated and does not require a signature.", W / 2, footerY + 5, { align: "center" });
  doc.text(`${companyName} · ${motto}`, W / 2, footerY + 10, { align: "center" });
  doc.text(`Generated: ${new Date().toLocaleDateString()}`, W / 2, footerY + 15, { align: "center" });

  // ── Download ──
  const filename = `Payslip-${payroll.employee_name?.replace(/\s+/g, "-") || payroll.employee_id}-${payroll.month}.pdf`;
  doc.save(filename);
}

// Hook-powered component for use inside React tree
export default function usePayslipDownload() {
  const { company } = useCompanyProfile();
  return (payroll) => generatePayslipPDF(payroll, company);
}
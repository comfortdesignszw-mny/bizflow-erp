import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import {
  LayoutDashboard,
  Users,
  Clock,
  QrCode,
  DollarSign,
  FileText,
  Briefcase,
  FolderKanban,
  BarChart3,
  Settings,
  ChevronLeft,
  ChevronRight,
  Building2,
  Menu,
  X,
  ClipboardList,
  BookOpen,
  ShoppingCart,
  Wrench,
  Cog,
  ChevronDown,
  Kanban
} from "lucide-react";
import { cn } from "@/lib/utils";

const navGroups = [
  {
    label: "Main",
    items: [
      { name: "Dashboard", icon: LayoutDashboard, page: "Dashboard" },
    ]
  },
  {
    label: "HR & People",
    items: [
      { name: "Employees", icon: Users, page: "Employees" },
      { name: "Attendance", icon: Clock, page: "Attendance" },
      { name: "Access Control", icon: QrCode, page: "AccessControl" },
      { name: "Payroll", icon: DollarSign, page: "Payroll" },
      { name: "Onboarding", icon: ClipboardList, page: "Onboarding" },
      { name: "Recruitment", icon: FileText, page: "Recruitment" },
      { name: "Vacancies", icon: Briefcase, page: "Vacancies" },
    ]
  },
  {
    label: "Departments",
    items: [
      { name: "Accounting", icon: BookOpen, page: "Accounting" },
      { name: "Sales & CRM", icon: ShoppingCart, page: "Sales" },
      { name: "Engineering", icon: Wrench, page: "Engineering" },
      { name: "Operations", icon: Cog, page: "Operations" },
    ]
  },
  {
    label: "Business",
    items: [
      { name: "Task Board", icon: Kanban, page: "Tasks" },
      { name: "Projects", icon: FolderKanban, page: "Projects" },
      { name: "Reports", icon: BarChart3, page: "Reports" },
      { name: "Settings", icon: Settings, page: "Settings" },
    ]
  }
];

export default function Sidebar({ currentPageName }) {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(true)}
        className="lg:hidden fixed top-4 left-4 z-50 p-2 bg-white rounded-xl shadow-lg border border-slate-200"
      >
        <Menu className="w-5 h-5 text-slate-700" />
      </button>

      {/* Mobile overlay */}
      {mobileOpen && (
        <div
          className="lg:hidden fixed inset-0 bg-black/30 backdrop-blur-sm z-40"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed top-0 left-0 h-full bg-white border-r border-slate-200 z-50 flex flex-col transition-all duration-300",
          collapsed ? "w-[72px]" : "w-[260px]",
          mobileOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        {/* Header */}
        <div className={cn("flex items-center h-16 border-b border-slate-100 px-4", collapsed && "justify-center")}>
          {!collapsed && (
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center">
                <Building2 className="w-4 h-4 text-white" />
              </div>
              <span className="font-semibold text-slate-900 text-[15px]">BizOps ERP</span>
            </div>
          )}
          {collapsed && (
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-600 to-violet-600 flex items-center justify-center">
              <Building2 className="w-4 h-4 text-white" />
            </div>
          )}
          <button
            onClick={() => setMobileOpen(false)}
            className="lg:hidden ml-auto p-1.5 hover:bg-slate-100 rounded-lg"
          >
            <X className="w-4 h-4 text-slate-500" />
          </button>
        </div>

        {/* Nav items */}
        <nav className="flex-1 py-3 px-2.5 overflow-y-auto space-y-1">
          {navGroups.map((group) => (
            <div key={group.label}>
              {!collapsed && (
                <p className="text-[10px] font-semibold text-slate-400 uppercase tracking-wider px-3 pt-3 pb-1">{group.label}</p>
              )}
              <div className="space-y-0.5">
                {group.items.map((item) => {
                  const isActive = currentPageName === item.page;
                  return (
                    <Link
                      key={item.page}
                      to={createPageUrl(item.page)}
                      onClick={() => setMobileOpen(false)}
                      className={cn(
                        "flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium transition-all",
                        isActive
                          ? "bg-indigo-50 text-indigo-700"
                          : "text-slate-600 hover:bg-slate-50 hover:text-slate-900"
                      )}
                    >
                      <item.icon className={cn("w-[18px] h-[18px] flex-shrink-0", isActive ? "text-indigo-600" : "text-slate-400")} />
                      {!collapsed && <span>{item.name}</span>}
                    </Link>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>

        {/* Collapse toggle - desktop only */}
        <div className="hidden lg:flex p-3 border-t border-slate-100">
          <button
            onClick={() => setCollapsed(!collapsed)}
            className="w-full flex items-center justify-center p-2 rounded-lg hover:bg-slate-50 text-slate-400 transition-colors"
          >
            {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
          </button>
        </div>
      </aside>
    </>
  );
}
import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { CheckCircle2, Circle, Loader2, X, Mail, BookOpen, CalendarDays, Monitor, ChevronRight, PartyPopper } from "lucide-react";
import { cn } from "@/lib/utils";
import { useCompanyProfile } from "@/components/brand/useCompanyProfile";

const STEPS = [
  {
    key: "welcome_email",
    icon: Mail,
    label: "Welcome Email",
    description: "Send welcome email with login details and first-day instructions",
    color: "text-cyan-600",
    bg: "bg-cyan-50",
    border: "border-cyan-200",
  },
  {
    key: "training_modules",
    icon: BookOpen,
    label: "Training Modules",
    description: "Assign initial onboarding training modules for the role",
    color: "text-blue-600",
    bg: "bg-blue-50",
    border: "border-blue-200",
  },
  {
    key: "welcome_meeting",
    icon: CalendarDays,
    label: "Welcome Meeting",
    description: "Schedule HR welcome meeting within the first week",
    color: "text-violet-600",
    bg: "bg-violet-50",
    border: "border-violet-200",
  },
  {
    key: "it_equipment",
    icon: Monitor,
    label: "IT Equipment",
    description: "Notify IT department to prepare workstation and access credentials",
    color: "text-emerald-600",
    bg: "bg-emerald-50",
    border: "border-emerald-200",
  },
];

export default function OnboardingWorkflow({ employee, onClose }) {
  const [stepStatus, setStepStatus] = useState({ welcome_email: "idle", training_modules: "idle", welcome_meeting: "idle", it_equipment: "idle" });
  const [currentStep, setCurrentStep] = useState(null);
  const [done, setDone] = useState(false);
  const [aiResults, setAiResults] = useState({});
  const { company } = useCompanyProfile();

  const companyName = company?.company_name || "Our Company";

  const runAll = async () => {
    for (const step of STEPS) {
      setCurrentStep(step.key);
      setStepStatus(prev => ({ ...prev, [step.key]: "running" }));
      try {
        let result = "";

        if (step.key === "welcome_email") {
          // Generate welcome email content via AI then send it
          const emailContent = await base44.integrations.Core.InvokeLLM({
            prompt: `Write a warm, professional welcome email for a new employee joining ${companyName}.
Employee name: ${employee.full_name}
Job title: ${employee.job_title}
Department: ${employee.department}
Employee ID: ${employee.employee_id}
Start date: ${employee.date_employed || "today"}

Include:
- Warm welcome message from the company
- Their employee ID and a reminder to set up their login using their email address (${employee.email || "to be provided by IT"})
- First-day instructions (arrive at 8:00 AM, bring ID documents, report to HR)
- Brief overview of what to expect in week 1
- Encouragement and excitement about joining the team

Keep it friendly, concise, and professional. Plain text only, no markdown.`,
          });

          if (employee.email) {
            await base44.integrations.Core.SendEmail({
              to: employee.email,
              subject: `Welcome to ${companyName}, ${employee.full_name}! 🎉`,
              body: emailContent,
              from_name: companyName,
            });
          }

          await base44.entities.OnboardingTask.create({
            employee_id: employee.employee_id,
            employee_name: employee.full_name,
            employee_email: employee.email || "",
            employee_department: employee.department,
            employee_job_title: employee.job_title,
            task_type: "welcome_email",
            task_label: "Welcome Email Sent",
            status: "completed",
            notes: employee.email ? `Email sent to ${employee.email}` : "No email on file — email generated but not sent",
          });

          result = emailContent.substring(0, 100) + "...";
          setAiResults(prev => ({ ...prev, welcome_email: emailContent }));
        }

        if (step.key === "training_modules") {
          const modules = await base44.integrations.Core.InvokeLLM({
            prompt: `Generate a structured 30-day onboarding training plan for a new ${employee.job_title} in the ${employee.department} department at ${companyName}.

Include 6–8 training modules with:
- Module name
- Week it should be completed (Week 1, 2, 3 or 4)
- Brief description (1 sentence)

Format as a clean numbered list. Keep it practical and role-specific.`,
          });

          await base44.entities.OnboardingTask.create({
            employee_id: employee.employee_id,
            employee_name: employee.full_name,
            employee_email: employee.email || "",
            employee_department: employee.department,
            employee_job_title: employee.job_title,
            task_type: "training_modules",
            task_label: "Training Plan Assigned",
            status: "completed",
            notes: modules,
          });

          setAiResults(prev => ({ ...prev, training_modules: modules }));
        }

        if (step.key === "welcome_meeting") {
          const agenda = await base44.integrations.Core.InvokeLLM({
            prompt: `Create a brief welcome meeting agenda for ${employee.full_name} (new ${employee.job_title}, ${employee.department} department) at ${companyName}.

The meeting is between the employee and HR. It should last 45–60 minutes in the first week.
Include 5–6 agenda items covering: company culture, policies overview, benefits explanation, team introductions, role expectations, Q&A.

Format as a numbered agenda list. Keep each item short (1 line).`,
          });

          await base44.entities.OnboardingTask.create({
            employee_id: employee.employee_id,
            employee_name: employee.full_name,
            employee_email: employee.email || "",
            employee_department: employee.department,
            employee_job_title: employee.job_title,
            task_type: "welcome_meeting",
            task_label: "HR Welcome Meeting Scheduled",
            status: "completed",
            notes: `Meeting to be scheduled in Week 1.\n\n${agenda}`,
          });

          setAiResults(prev => ({ ...prev, welcome_meeting: agenda }));
        }

        if (step.key === "it_equipment") {
          const itTicket = await base44.integrations.Core.InvokeLLM({
            prompt: `Generate an IT equipment preparation checklist for a new employee at ${companyName}.

Employee: ${employee.full_name}
Role: ${employee.job_title}
Department: ${employee.department}
Employee ID: ${employee.employee_id}
Start date: ${employee.date_employed || "TBD"}

List the standard equipment and accounts IT should prepare. Include hardware, software access, accounts/credentials, and security setup. Format as a numbered checklist.`,
          });

          await base44.entities.OnboardingTask.create({
            employee_id: employee.employee_id,
            employee_name: employee.full_name,
            employee_email: employee.email || "",
            employee_department: employee.department,
            employee_job_title: employee.job_title,
            task_type: "it_equipment",
            task_label: "IT Equipment Request Sent",
            status: "completed",
            notes: itTicket,
          });

          setAiResults(prev => ({ ...prev, it_equipment: itTicket }));
        }

        setStepStatus(prev => ({ ...prev, [step.key]: "done" }));
      } catch (err) {
        setStepStatus(prev => ({ ...prev, [step.key]: "failed" }));
        await base44.entities.OnboardingTask.create({
          employee_id: employee.employee_id,
          employee_name: employee.full_name,
          task_type: step.key,
          task_label: step.label,
          status: "failed",
          notes: err?.message || "Unknown error",
        });
      }
    }
    setCurrentStep(null);
    setDone(true);
  };

  useEffect(() => {
    runAll();
  }, []);

  const allDone = STEPS.every(s => stepStatus[s.key] === "done" || stepStatus[s.key] === "failed");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div className="relative z-10 w-full max-w-md mx-4 bg-white rounded-2xl shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-cyan-500 to-blue-600 px-6 py-5">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white/80 text-xs font-medium uppercase tracking-wider">Employee Onboarding</p>
              <h2 className="text-white font-bold text-lg mt-0.5">{employee.full_name}</h2>
              <p className="text-white/70 text-xs mt-0.5">{employee.job_title} · {employee.department}</p>
            </div>
            {allDone && (
              <button onClick={onClose} className="text-white/70 hover:text-white p-1 rounded-lg">
                <X className="w-5 h-5" />
              </button>
            )}
          </div>
        </div>

        {/* Steps */}
        <div className="p-5 space-y-3">
          {STEPS.map((step) => {
            const status = stepStatus[step.key];
            const Icon = step.icon;
            const isRunning = status === "running";
            const isDone = status === "done";
            const isFailed = status === "failed";
            const isIdle = status === "idle";

            return (
              <div
                key={step.key}
                className={cn(
                  "flex items-start gap-3 p-3 rounded-xl border transition-all duration-300",
                  isDone ? `${step.bg} ${step.border}` : isFailed ? "bg-rose-50 border-rose-200" : isRunning ? "bg-slate-50 border-slate-200 shadow-sm" : "bg-slate-50 border-slate-100"
                )}
              >
                <div className={cn(
                  "w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0",
                  isDone ? step.bg : isFailed ? "bg-rose-100" : isRunning ? "bg-white border border-slate-200" : "bg-white border border-slate-200"
                )}>
                  {isRunning ? (
                    <Loader2 className="w-4 h-4 text-slate-400 animate-spin" />
                  ) : isDone ? (
                    <CheckCircle2 className={cn("w-5 h-5", step.color)} />
                  ) : isFailed ? (
                    <X className="w-4 h-4 text-rose-500" />
                  ) : (
                    <Icon className="w-4 h-4 text-slate-300" />
                  )}
                </div>

                <div className="flex-1 min-w-0">
                  <p className={cn("text-sm font-semibold", isDone ? "text-slate-800" : isFailed ? "text-rose-700" : "text-slate-500")}>
                    {step.label}
                    {isRunning && <span className="ml-2 text-xs font-normal text-slate-400 animate-pulse">Processing...</span>}
                    {isDone && <span className={cn("ml-2 text-xs font-normal", step.color)}>Done ✓</span>}
                    {isFailed && <span className="ml-2 text-xs font-normal text-rose-500">Failed</span>}
                  </p>
                  <p className="text-xs text-slate-400 mt-0.5 leading-relaxed">{step.description}</p>
                  {isDone && aiResults[step.key] && (
                    <details className="mt-1.5">
                      <summary className={cn("text-xs cursor-pointer font-medium", step.color)}>View result</summary>
                      <pre className="mt-1 text-xs text-slate-500 whitespace-pre-wrap leading-relaxed max-h-32 overflow-y-auto">{aiResults[step.key]}</pre>
                    </details>
                  )}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="px-5 pb-5">
          {!allDone ? (
            <div className="flex items-center gap-2 text-xs text-slate-400 bg-slate-50 rounded-xl px-3 py-2.5">
              <Loader2 className="w-3.5 h-3.5 animate-spin flex-shrink-0" />
              Running onboarding automation — please wait, this takes a few seconds…
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center gap-2 text-xs text-emerald-700 bg-emerald-50 border border-emerald-200 rounded-xl px-3 py-2.5">
                <PartyPopper className="w-3.5 h-3.5 flex-shrink-0" />
                All onboarding tasks completed! {employee.full_name} is set to start.
              </div>
              <Button onClick={onClose} className="w-full h-10 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 gap-1.5">
                Done <ChevronRight className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
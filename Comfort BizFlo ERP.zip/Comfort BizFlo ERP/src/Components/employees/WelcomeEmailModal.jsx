import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Mail, Loader2, Send, Copy, CheckCheck, Sparkles } from "lucide-react";

export default function WelcomeEmailModal({ employee, open, onClose }) {
  const [generating, setGenerating] = useState(false);
  const [sending, setSending] = useState(false);
  const [emailContent, setEmailContent] = useState(null);
  const [copied, setCopied] = useState(false);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (open && employee && !emailContent) {
      generateEmail();
    }
  }, [open, employee]);

  const generateEmail = async () => {
    setGenerating(true);
    const tempPassword = `Welcome@${Math.floor(1000 + Math.random() * 9000)}`;
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `Generate a professional, warm welcome email for a new employee joining the company.
Employee details:
- Full Name: ${employee.full_name}
- Employee ID: ${employee.employee_id}
- Job Title: ${employee.job_title}
- Department: ${employee.department}
- Date Employed: ${employee.date_employed || "today"}
- Email: ${employee.email}

Include:
1. A warm, personalized welcome greeting
2. Their login details: Username: ${employee.email || employee.employee_id}, Temporary Password: ${tempPassword}
3. First-day onboarding checklist (5-7 items like: complete IT setup, meet team lead, review company handbook, set up email signature, attend orientation, etc.)
4. Key company information (working hours 8am-5pm, probation period 3 months, IT helpdesk support@company.com)
5. A motivating closing statement
Keep the tone professional yet friendly. Format nicely with sections.`,
      response_json_schema: {
        type: "object",
        properties: {
          subject: { type: "string" },
          greeting: { type: "string" },
          login_section: { type: "string" },
          onboarding_checklist: { type: "array", items: { type: "string" } },
          company_info: { type: "string" },
          closing: { type: "string" },
          temp_password: { type: "string" },
        },
      },
    });
    result.temp_password = tempPassword;
    setEmailContent(result);
    setGenerating(false);
  };

  const handleSendEmail = async () => {
    if (!employee.email) return;
    setSending(true);
    const body = `${emailContent.greeting}\n\n${emailContent.login_section}\n\nYour Onboarding Checklist:\n${emailContent.onboarding_checklist?.map((item, i) => `${i + 1}. ${item}`).join("\n")}\n\n${emailContent.company_info}\n\n${emailContent.closing}`;
    await base44.integrations.Core.SendEmail({
      to: employee.email,
      subject: emailContent.subject || `Welcome to the Team, ${employee.full_name}!`,
      body,
    });
    setSending(false);
    setSent(true);
  };

  const handleCopy = () => {
    const text = `Subject: ${emailContent.subject}\n\n${emailContent.greeting}\n\n${emailContent.login_section}\n\nOnboarding Checklist:\n${emailContent.onboarding_checklist?.map((item, i) => `${i + 1}. ${item}`).join("\n")}\n\n${emailContent.company_info}\n\n${emailContent.closing}`;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-indigo-500" />
            AI-Generated Welcome Email
          </DialogTitle>
        </DialogHeader>

        {generating ? (
          <div className="flex flex-col items-center justify-center py-16 gap-3">
            <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
            <p className="text-sm text-slate-500">Generating personalized welcome email...</p>
          </div>
        ) : emailContent ? (
          <div className="space-y-4">
            {/* Subject */}
            <div className="bg-slate-50 rounded-xl p-3 border border-slate-200">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Subject</p>
              <p className="text-sm font-medium text-slate-800">{emailContent.subject}</p>
            </div>

            {/* Greeting */}
            <div className="space-y-1">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide">Greeting</p>
              <p className="text-sm text-slate-700 whitespace-pre-line">{emailContent.greeting}</p>
            </div>

            {/* Login Details */}
            <div className="bg-indigo-50 rounded-xl p-4 border border-indigo-100">
              <p className="text-xs font-semibold text-indigo-600 uppercase tracking-wide mb-2">Login Details</p>
              <p className="text-sm text-slate-700 whitespace-pre-line">{emailContent.login_section}</p>
              <div className="mt-2 flex gap-2 flex-wrap">
                <Badge className="bg-indigo-100 text-indigo-700 border-indigo-200">
                  Username: {employee.email || employee.employee_id}
                </Badge>
                <Badge className="bg-amber-100 text-amber-700 border-amber-200">
                  Temp Password: {emailContent.temp_password}
                </Badge>
              </div>
            </div>

            {/* Onboarding Checklist */}
            <div>
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-2">Onboarding Checklist</p>
              <ul className="space-y-1.5">
                {emailContent.onboarding_checklist?.map((item, i) => (
                  <li key={i} className="flex items-start gap-2 text-sm text-slate-700">
                    <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">{i + 1}</span>
                    {item}
                  </li>
                ))}
              </ul>
            </div>

            {/* Company Info */}
            <div className="bg-slate-50 rounded-xl p-3 border border-slate-200">
              <p className="text-xs font-semibold text-slate-500 uppercase tracking-wide mb-1">Company Information</p>
              <p className="text-sm text-slate-700 whitespace-pre-line">{emailContent.company_info}</p>
            </div>

            {/* Closing */}
            <p className="text-sm text-slate-700 whitespace-pre-line">{emailContent.closing}</p>

            {/* Actions */}
            <div className="flex gap-2 pt-2 border-t border-slate-100">
              <Button variant="outline" onClick={handleCopy} className="gap-2 rounded-xl">
                {copied ? <CheckCheck className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
                {copied ? "Copied!" : "Copy"}
              </Button>
              <Button variant="outline" onClick={generateEmail} className="gap-2 rounded-xl">
                <Sparkles className="w-4 h-4" /> Regenerate
              </Button>
              {employee.email && (
                <Button
                  onClick={handleSendEmail}
                  disabled={sending || sent}
                  className="gap-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 ml-auto"
                >
                  {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  {sent ? "Email Sent!" : sending ? "Sending..." : "Send Email"}
                </Button>
              )}
              {!employee.email && (
                <p className="text-xs text-amber-600 ml-auto self-center">No email on file — copy and send manually</p>
              )}
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
import React, { useState, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { base44 } from "@/api/base44Client";
import { X, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";
import EmployeeQRCode from "./EmployeeQRCode";
import WelcomeEmailModal from "./WelcomeEmailModal";
import OnboardingWorkflow from "./OnboardingWorkflow";

const DEPARTMENTS = ["Engineering", "Marketing", "Sales", "Finance", "HR", "Operations", "IT", "Legal", "Support", "Executive"];
const EMP_TYPES = ["Full-time", "Part-time", "Contract"];
const GENDERS = ["Male", "Female", "Other"];
const SECTIONS = ["Personal", "Employment", "Banking", "Emergency"];

// Defined OUTSIDE component so they never get recreated on re-render
const Field = React.memo(({ label, field, type = "text", required, inputMode, value, onChange }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-medium text-slate-600">
      {label}{required && <span className="text-rose-500 ml-0.5">*</span>}
    </Label>
    <Input
      type={type}
      inputMode={inputMode}
      value={value || ""}
      onChange={(e) => onChange(field, e.target.value)}
      className="h-11 text-base rounded-xl border-slate-200 focus:border-indigo-400"
      required={required}
      autoComplete="off"
    />
  </div>
));

const SelectField = React.memo(({ label, field, options, required, value, onChange }) => (
  <div className="space-y-1.5">
    <Label className="text-xs font-medium text-slate-600">
      {label}{required && <span className="text-rose-500 ml-0.5">*</span>}
    </Label>
    <Select value={value || ""} onValueChange={(v) => onChange(field, v)}>
      <SelectTrigger className="h-11 text-base rounded-xl border-slate-200">
        <SelectValue placeholder={`Select ${label}`} />
      </SelectTrigger>
      <SelectContent>
        {options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}
      </SelectContent>
    </Select>
  </div>
));

export default function EmployeeForm({ open, onClose, employee, onSaved }) {
  const [form, setForm] = useState(() => employee || {
    employee_id: `EMP-${Date.now().toString().slice(-6)}`,
    full_name: "", national_id: "", gender: "", date_of_birth: "",
    phone: "", email: "", address: "", department: "", job_title: "",
    employment_type: "Full-time", date_employed: new Date().toISOString().split("T")[0],
    salary: "", bank_name: "", bank_account: "",
    next_of_kin_name: "", next_of_kin_phone: "",
    emergency_contact_name: "", emergency_contact_phone: "",
    status: "Active",
  });
  const [saving, setSaving] = useState(false);
  const [activeSection, setActiveSection] = useState(0);
  const [showQR, setShowQR] = useState(false);
  const [showWelcomeEmail, setShowWelcomeEmail] = useState(false);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [savedEmployee, setSavedEmployee] = useState(null);
  const scrollRef = useRef(null);

  const handleChange = useCallback((field, value) => {
    setForm(prev => ({ ...prev, [field]: value }));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    const data = { ...form, salary: Number(form.salary) || 0, qr_code: form.qr_code || `QR-${form.employee_id}` };
    let saved;
    if (employee?.id) {
      saved = await base44.entities.Employee.update(employee.id, data);
    } else {
      saved = await base44.entities.Employee.create(data);
    }
    setSaving(false);
    onSaved();
    const empData = saved || { ...data, id: employee?.id };
    setSavedEmployee(empData);
    setShowQR(true);
    if (!employee?.id) {
      setShowWelcomeEmail(false);
    }
  };

  const f = (field) => form[field];

  const sections = [
    {
      title: "Personal Details",
      fields: (
        <div className="grid grid-cols-1 gap-4">
          <Field label="Employee ID" field="employee_id" required value={f("employee_id")} onChange={handleChange} />
          <Field label="Full Name" field="full_name" required value={f("full_name")} onChange={handleChange} />
          <Field label="National ID / Passport" field="national_id" value={f("national_id")} onChange={handleChange} />
          <SelectField label="Gender" field="gender" options={GENDERS} value={f("gender")} onChange={handleChange} />
          <Field label="Date of Birth" field="date_of_birth" type="date" value={f("date_of_birth")} onChange={handleChange} />
          <Field label="Phone" field="phone" type="tel" inputMode="tel" value={f("phone")} onChange={handleChange} />
          <Field label="Email" field="email" type="email" inputMode="email" value={f("email")} onChange={handleChange} />
          <Field label="Address" field="address" value={f("address")} onChange={handleChange} />
        </div>
      ),
    },
    {
      title: "Employment",
      fields: (
        <div className="grid grid-cols-1 gap-4">
          <SelectField label="Department" field="department" options={DEPARTMENTS} required value={f("department")} onChange={handleChange} />
          <Field label="Job Title" field="job_title" required value={f("job_title")} onChange={handleChange} />
          <SelectField label="Employment Type" field="employment_type" options={EMP_TYPES} value={f("employment_type")} onChange={handleChange} />
          <Field label="Date Employed" field="date_employed" type="date" value={f("date_employed")} onChange={handleChange} />
          <Field label="Salary" field="salary" type="number" inputMode="decimal" value={f("salary")} onChange={handleChange} />
        </div>
      ),
    },
    {
      title: "Banking",
      fields: (
        <div className="grid grid-cols-1 gap-4">
          <Field label="Bank Name" field="bank_name" value={f("bank_name")} onChange={handleChange} />
          <Field label="Bank Account Number" field="bank_account" inputMode="numeric" value={f("bank_account")} onChange={handleChange} />
        </div>
      ),
    },
    {
      title: "Emergency Contacts",
      fields: (
        <div className="grid grid-cols-1 gap-4">
          <Field label="Next of Kin Name" field="next_of_kin_name" value={f("next_of_kin_name")} onChange={handleChange} />
          <Field label="Next of Kin Phone" field="next_of_kin_phone" type="tel" inputMode="tel" value={f("next_of_kin_phone")} onChange={handleChange} />
          <Field label="Emergency Contact Name" field="emergency_contact_name" value={f("emergency_contact_name")} onChange={handleChange} />
          <Field label="Emergency Contact Phone" field="emergency_contact_phone" type="tel" inputMode="tel" value={f("emergency_contact_phone")} onChange={handleChange} />
        </div>
      ),
    },
  ];

  if (!open && !showQR) return null;

  if (showOnboarding && savedEmployee) {
    return <OnboardingWorkflow employee={savedEmployee} onClose={() => { setShowOnboarding(false); onClose(); }} />;
  }

  if (showWelcomeEmail && savedEmployee) {
    return (
      <WelcomeEmailModal
        employee={savedEmployee}
        open={showWelcomeEmail}
        onClose={() => { setShowWelcomeEmail(false); onClose(); }}
      />
    );
  }

  if (showQR && savedEmployee) {
    return (
      <EmployeeQRCode
        employee={savedEmployee}
        open={showQR}
        onClose={() => {
          setShowQR(false);
          if (!employee?.id) {
            setShowOnboarding(true);
          } else {
            onClose();
          }
        }}
      />
    );
  }

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      <div
        className="relative z-10 w-full sm:max-w-lg sm:mx-4 bg-white sm:rounded-2xl flex flex-col"
        style={{ height: "100dvh", maxHeight: "100dvh" }}
      >
        {/* Fixed Header */}
        <div className="flex items-center justify-between px-4 pt-4 pb-3 border-b border-slate-100 flex-shrink-0">
          <h2 className="text-base font-semibold text-slate-900">
            {employee ? "Edit Employee" : "Add New Employee"}
          </h2>
          <button onClick={onClose} className="p-2 rounded-xl hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5 text-slate-500" />
          </button>
        </div>

        {/* Section Tabs */}
        <div className="flex gap-1 px-4 pt-3 pb-2 overflow-x-auto flex-shrink-0 scrollbar-none">
          {SECTIONS.map((sec, i) => (
            <button
              key={sec}
              type="button"
              onClick={() => {
                setActiveSection(i);
                scrollRef.current?.scrollTo({ top: 0, behavior: "smooth" });
              }}
              className={cn(
                "flex-shrink-0 px-3 py-1.5 rounded-lg text-xs font-medium transition-all",
                activeSection === i ? "bg-indigo-600 text-white" : "bg-slate-100 text-slate-600"
              )}
            >
              {sec}
            </button>
          ))}
        </div>

        {/* Scrollable Form Body */}
        <form onSubmit={handleSubmit} className="flex flex-col flex-1 min-h-0">
          <div
            ref={scrollRef}
            className="flex-1 overflow-y-auto px-4 py-3"
            style={{ overscrollBehavior: "contain", WebkitOverflowScrolling: "touch" }}
          >
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider mb-4">
              {sections[activeSection].title}
            </p>
            {sections[activeSection].fields}
            <div className="h-6" />
          </div>

          {/* Fixed Footer */}
          <div className="flex-shrink-0 px-4 pb-6 pt-3 border-t border-slate-100 bg-white">
            <div className="flex gap-3">
              {activeSection > 0 && (
                <Button
                  type="button"
                  variant="outline"
                  className="flex-1 h-11 rounded-xl"
                  onClick={() => {
                    setActiveSection(prev => prev - 1);
                    scrollRef.current?.scrollTo({ top: 0 });
                  }}
                >
                  Back
                </Button>
              )}
              {activeSection < sections.length - 1 ? (
                <Button
                  type="button"
                  className="flex-1 h-11 bg-indigo-600 hover:bg-indigo-700 rounded-xl gap-1"
                  onClick={() => {
                    setActiveSection(prev => prev + 1);
                    scrollRef.current?.scrollTo({ top: 0 });
                  }}
                >
                  Next <ChevronRight className="w-4 h-4" />
                </Button>
              ) : (
                <Button
                  type="submit"
                  disabled={saving}
                  className="flex-1 h-11 bg-indigo-600 hover:bg-indigo-700 rounded-xl"
                >
                  {saving ? "Saving..." : employee ? "Update Employee" : "Add Employee"}
                </Button>
              )}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}
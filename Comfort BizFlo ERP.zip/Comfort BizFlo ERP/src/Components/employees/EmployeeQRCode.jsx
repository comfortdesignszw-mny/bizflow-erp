import React, { useEffect, useRef, useState } from "react";
import QRCode from "qrcode";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Download, QrCode } from "lucide-react";
import { useCompanyProfile } from "@/components/brand/useCompanyProfile";

export default function EmployeeQRCode({ employee, open, onClose }) {
  const canvasRef = useRef(null);
  const [dataUrl, setDataUrl] = useState(null);
  const { company } = useCompanyProfile();

  useEffect(() => {
    if (!open || !employee) return;
    generateQR();
  }, [open, employee, company]);

  const generateQR = async () => {
    const payload = JSON.stringify({
      employee_id: employee.employee_id,
      full_name: employee.full_name,
      department: employee.department,
      job_title: employee.job_title,
      phone: employee.phone || "",
      email: employee.email || "",
    });

    const qrDataUrl = await QRCode.toDataURL(payload, {
      width: 300,
      margin: 2,
      color: { dark: "#0e7490", light: "#ffffff" }, // cyan-700
    });

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    canvas.width = 420;
    canvas.height = 580;

    // ── Background gradient: cyan → blue ──
    const grad = ctx.createLinearGradient(0, 0, 0, 580);
    grad.addColorStop(0, "#06b6d4");   // cyan-500
    grad.addColorStop(1, "#1d4ed8");   // blue-700
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 420, 580);

    // ── White card body ──
    ctx.fillStyle = "#ffffff";
    roundRect(ctx, 16, 130, 388, 430, 18);
    ctx.fill();

    // ── Cyan accent stripe on card top ──
    ctx.fillStyle = "#ecfeff"; // cyan-50
    roundRect(ctx, 16, 130, 388, 10, 0);
    ctx.fill();

    // ── Header: Company name ──
    const companyName = company?.company_name || "BizOps ERP";
    const motto = company?.motto || "";

    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 20px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("EMPLOYEE ID CARD", 210, 48);

    ctx.font = "bold 14px sans-serif";
    ctx.fillStyle = "rgba(255,255,255,0.95)";
    ctx.fillText(companyName.toUpperCase(), 210, 72);

    if (motto) {
      ctx.font = "italic 11px sans-serif";
      ctx.fillStyle = "rgba(255,255,255,0.75)";
      ctx.fillText(motto, 210, 90);
    }

    // ── Logo or initial circle ──
    ctx.fillStyle = "rgba(255,255,255,0.25)";
    ctx.beginPath();
    ctx.arc(210, 128, 44, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#0e7490"; // cyan-700
    ctx.font = "bold 32px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(employee.full_name?.charAt(0)?.toUpperCase() || "?", 210, 138);

    // ── Employee name ──
    ctx.fillStyle = "#0f172a";
    ctx.font = "bold 17px sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(employee.full_name || "", 210, 200);

    // ── Job title (cyan) ──
    ctx.fillStyle = "#0891b2"; // cyan-600
    ctx.font = "600 13px sans-serif";
    ctx.fillText(employee.job_title || "", 210, 220);

    // ── Department ──
    ctx.fillStyle = "#64748b";
    ctx.font = "12px sans-serif";
    ctx.fillText(employee.department || "", 210, 238);

    // ── Divider ──
    ctx.strokeStyle = "#e0f2fe"; // cyan-100
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(36, 254);
    ctx.lineTo(384, 254);
    ctx.stroke();

    // ── Info rows ──
    const rows = [
      { label: "Employee ID", value: employee.employee_id },
      { label: "Phone", value: employee.phone || "—" },
      { label: "Email", value: (employee.email || "—").substring(0, 32) },
    ];
    ctx.textAlign = "left";
    rows.forEach((row, i) => {
      const y = 278 + i * 30;
      ctx.fillStyle = "#94a3b8";
      ctx.font = "10px sans-serif";
      ctx.fillText(row.label.toUpperCase(), 36, y - 10);
      ctx.fillStyle = "#0f172a";
      ctx.font = "13px sans-serif";
      ctx.fillText(row.value, 36, y + 4);
    });

    // ── QR code ──
    const qrImg = new Image();
    qrImg.onload = () => {
      // QR background rounded rect
      ctx.fillStyle = "#f0fdff"; // cyan-50
      roundRect(ctx, 140, 370, 140, 140, 10);
      ctx.fill();

      ctx.drawImage(qrImg, 148, 378, 124, 124);

      // Footer text inside card
      ctx.fillStyle = "#94a3b8";
      ctx.font = "9px sans-serif";
      ctx.textAlign = "center";
      ctx.fillText("Scan to check in / check out", 210, 522);

      // ── Footer strip ──
      ctx.fillStyle = "rgba(255,255,255,0.15)";
      ctx.fillRect(16, 549, 388, 1);

      if (company?.website || company?.phone) {
        ctx.fillStyle = "rgba(255,255,255,0.7)";
        ctx.font = "10px sans-serif";
        ctx.textAlign = "center";
        const footerText = [company?.website, company?.phone].filter(Boolean).join("  |  ");
        ctx.fillText(footerText, 210, 566);
      }

      setDataUrl(canvas.toDataURL("image/png"));
    };
    qrImg.src = qrDataUrl;
  };

  const handleDownload = () => {
    if (!dataUrl) return;
    const a = document.createElement("a");
    a.href = dataUrl;
    a.download = `ID-Card-${employee.employee_id}-${employee.full_name?.replace(/\s+/g, "-")}.png`;
    a.click();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <QrCode className="w-4 h-4 text-cyan-600" /> Employee ID Card
          </DialogTitle>
        </DialogHeader>

        <div className="flex flex-col items-center gap-4">
          <canvas ref={canvasRef} className="hidden" />

          {dataUrl ? (
            <img src={dataUrl} alt="ID Card" className="w-full rounded-xl border border-cyan-200 shadow" />
          ) : (
            <div className="w-full h-48 bg-cyan-50 rounded-xl flex items-center justify-center">
              <QrCode className="w-8 h-8 text-cyan-300 animate-pulse" />
            </div>
          )}

          <p className="text-xs text-slate-500 text-center">
            This ID card contains employee info. When scanned at the Access Control station, it will automatically record check-in/out and attendance.
          </p>

          <div className="flex gap-2 w-full">
            <Button onClick={handleDownload} disabled={!dataUrl} className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 gap-2">
              <Download className="w-4 h-4" /> Download Card
            </Button>
            <Button variant="outline" onClick={onClose} className="px-4">Close</Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.lineTo(x + w - r, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + r);
  ctx.lineTo(x + w, y + h - r);
  ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
  ctx.lineTo(x + r, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - r);
  ctx.lineTo(x, y + r);
  ctx.quadraticCurveTo(x, y, x + r, y);
  ctx.closePath();
}